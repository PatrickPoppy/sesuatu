### Description of Your Pull Request
What does your pull request specifically does by adding/modifying or removing code?

### Changes Proposed and or Files Changed
- Example Change

### Label Your Pull Request
- [ ] This PR modifies existing code to enhance the bot
- [ ] This PR fixes a bug within the bot
- [ ] This PR removes/renames methods or properties
- [ ] This PR adds methods, features, commands or properties
